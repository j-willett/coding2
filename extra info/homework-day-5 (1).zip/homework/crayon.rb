puts "What is your favorite Crayola crayon?"
input = gets.chomp

puts input.reverse.upcase
