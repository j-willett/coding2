puts "Please type a sentence"
sentence = gets.chomp.downcase.split

puts "What is your favroite word in that sentence?"
word = gets.chomp.downcase

favorite_word_index = sentence.index(word)

if favorite_word_index.nil?
  puts "That word is not in the sentence"
else
  puts "That word starts at (word) position #{favorite_word_index}"
end
