puts "How are you feeling today?"
input = gets.chomp

puts "length: " + input.length.to_s
puts input.prepend("meow")
puts "meow" + input
puts "meow#{input}"
