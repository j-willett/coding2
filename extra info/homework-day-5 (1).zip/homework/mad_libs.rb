puts "Let's play MADLIBS"
puts "Please give me a noun"
noun = gets.chomp

puts "Please give me a verb"
verb = gets.chomp

puts "Please give me an adjective"
adjective = gets.chomp

puts "Please give me an adverb"
adverb = gets.chomp

puts "Please give me a preposition"
preposition = gets.chomp

puts "Please give me an exclamation"
exclamation = gets.chomp

puts "#{exclamation}!!!!! I was #{adverb} running down the street when a #{noun} suddenly appeared #{preposition} me. It told me to #{verb} the #{adjective} #{noun} immediately"
