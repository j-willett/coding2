puts "Please give me a number"
num1 = gets.chomp.to_i

puts "Please give me a second number"
num2 = gets.chomp.to_i

sum = num1 + num2
diff = num1 - num2
prod = num1 * num2
if num2 != 0
  quotient = num1 / num2
  remainder = num1 % num2
end

puts "The sum of #{num1} and #{num2} is #{sum}"
puts "The difference between #{num1} and #{num2} is #{diff}"
puts "The product of #{num1} and #{num2} is #{prod}"
if num2 != 0
  puts "The quotient of #{num1} and #{num2} is #{quotient}"
  puts "The remainder of #{num1} and #{num2} is #{remainder}"
else
  puts "Sorry I can't divide by zero"
end
