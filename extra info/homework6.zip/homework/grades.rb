puts "What was your grade on the test (1-100)?"
input = gets.chomp.to_i

if (90..100).include?(input)
  puts "You got an A"
elsif (80..89).include?(input)
  puts "You got a B"
elsif (70..79).include?(input)
  puts "You got a C"
elsif (60..69).include?(input)
  puts "You got a D"
elsif input > 100
  puts "There was no extra credit, cheater."
else
  puts "You FAILED"
end
