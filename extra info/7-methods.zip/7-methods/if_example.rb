puts "What's your age?"
age = gets.chomp.to_i

puts age > 21 ? "You can drink" : "Get outta here."
