def add(x, y)
  x + y
end

def sub(x, y)
  x - y
end

def mul(x, y)
  x * y
end

def div(x, y)
  x / y
end

def mod(x, y)
  x % y
end

# main program
puts "Please enter a number"
num1 = gets.chomp.to_i

puts "Please enter a second number"
num2 = gets.chomp.to_i

puts "Which operation would you like to perform? (add, sub, mul, div, mod)"
op = gets.chomp

case op
when 'add', '+', 'addition', 'sum' then add(num1, num2)
when 'sub' then sub(num1, num2)
when 'mul' then mul(num1, num2)
when 'div' then div(num1, num2)
when 'mod' then mod(num1, num2)
end
