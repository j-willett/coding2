var playerScore = 0;
var computerScore = 0;
var roundNumber = 1;

function randomThrow() {
  var randomIndex = Math.floor(Math.random() * 3);
  return ['rock', 'paper', 'scissors'][randomIndex];
}

function updateScoreboard() {
  $('#player-score').text(playerScore);
  $('#computer-score').text(computerScore);
}



function playRound(playerThrow) {
  var computerThrow = randomThrow();
  var result;

  if (computerThrow === playerThrow) {
    result = 'TIE';
  } else if ((playerThrow == 'rock' && computerThrow == 'scissors') ||
             (playerThrow == 'paper' && computerThrow == 'rock') ||
             (playerThrow == 'scissors' && computerThrow == 'paper')) {
    result = 'PLAYER WIN';
    playerScore++;
  } else {
    result = 'COMPUTER WIN';
    computerScore++;
  }

  updateScoreboard();
  updateLog(playerThrow, computerThrow, result);
  roundNumber++;
}

function updateLog(playerThrow, computerThrow, result) {
  $('tbody').append(`<tr><td>${roundNumber}</td><td>${playerThrow}</td><td>${computerThrow}</td><td>${result}</td><td>${playerScore}-${computerScore}</td></tr>`)
}
